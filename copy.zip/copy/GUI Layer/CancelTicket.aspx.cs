﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Business_Layer;
using System.Data;
namespace GUI_Layer
{
    public partial class Cancel_Ticket : System.Web.UI.Page
    {
        Bal b = new Bal();
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        protected void Button1_Click(object sender, EventArgs e)
        {
         try
            {
                int res = b.cancel_booking(int.Parse(txtbid.Text));

                if (res > 0) //ie 1 row affected in SQL for Insertion
                {
                    Response.Write("<script>alert('Ticket Cancelled Successfully');window.location.href='CustomerFacility.aspx';</script>");
                   

                 }

            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
           
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
         Response.Redirect("CustomerFacility.aspx");
        }
        


       
    }
}