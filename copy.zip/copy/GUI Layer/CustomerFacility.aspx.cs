﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Business_Layer;
using System.Data;

namespace GUI_Layer
{
    public partial class CustomerPage : System.Web.UI.Page
    {
        Bal b = new Bal();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                Label1.Text = Session["Customer_id"].ToString();
                DataTable dt = b.display_name_bll(Convert.ToInt32(Label1.Text));

                if (dt.Rows.Count > 0)
                {
                    name_lbl.Text = dt.Rows[0]["Name"].ToString();
                }
                else
                {
                    Response.Write("No Customer Exist");
                }

                
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Myhome.aspx");
            Response.Write("Logout Successfully");
           
        }

        protected void LinkButton4_Click(object sender, EventArgs e)
        {
            Session["Customer_id"] = Label1.Text.ToString();
            Response.Redirect("EditProfile.aspx");
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Session["cid"] = Label1.Text.ToString();
            
            Response.Redirect("Search Flight.aspx");
        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            Response.Redirect("BookTicket.aspx?cid=" + Label1.Text.ToString());
        }
    }
}